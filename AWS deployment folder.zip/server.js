'use strict';

const {start, app} = require('./src/server');
require('dotenv').config();

start();